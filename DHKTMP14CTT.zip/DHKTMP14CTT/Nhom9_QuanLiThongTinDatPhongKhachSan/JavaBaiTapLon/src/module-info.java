module JavaBaiTapLon {
	requires java.desktop;
	requires java.sql;
}