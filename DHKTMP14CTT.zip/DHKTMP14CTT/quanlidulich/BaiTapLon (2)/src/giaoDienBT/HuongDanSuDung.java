package giaoDienBT;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class HuongDanSuDung extends JFrame implements ActionListener{
	
	public HuongDanSuDung() {
		
		super("Hướng Dẫn Sử Dụng");
		setSize(800, 800);
		setLocationRelativeTo(null);
		setResizable(false);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	


}
