package app;

public class Starting {
	public static void main(final String[] args) {
		final FrmMenu frm = new FrmMenu();
		frm.setVisible(true);
	}
}
