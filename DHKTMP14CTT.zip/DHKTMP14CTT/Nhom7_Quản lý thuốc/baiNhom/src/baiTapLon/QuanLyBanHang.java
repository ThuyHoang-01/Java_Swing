package baiTapLon;

public class QuanLyBanHang {
	public static void thongKeDoanhThu() {
		// ket noi csdl
	}
	public static void thongKeDonThuoc() {
		// ket noi csdl
	}
	public static void thongKeKhachHang() {
		// ket noi csdl
	}
	public static void lapSoLuongThuocHetHan() {
		// ket noi csdl
	}
	public static void lapSoLuongThuocMoiNhap() {
		// ket noi csdl
	}
}
