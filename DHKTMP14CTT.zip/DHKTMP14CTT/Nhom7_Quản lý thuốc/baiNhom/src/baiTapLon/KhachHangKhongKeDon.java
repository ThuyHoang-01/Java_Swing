package baiTapLon;

public class KhachHangKhongKeDon extends KhachHang {

	public KhachHangKhongKeDon(String maKhachHang) {
		super(maKhachHang);
		// TODO Auto-generated constructor stub
	}
	
}
