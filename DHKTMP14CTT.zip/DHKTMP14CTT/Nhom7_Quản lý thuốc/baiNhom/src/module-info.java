module baiNhom {
	requires java.desktop;
	requires java.sql;
}