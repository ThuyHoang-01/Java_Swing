package main; 

import GiaoDien.GiaoDienTong;

public class MainRun {
	
	public static void main(String[] args) {
		new GiaoDienTong().setVisible(true);
	}

}
