package DoiTuong;

public class ChucVu {
    private String ID,tenCV,IDPhongBan;

    public String getID() {
        return ID;
    }

    public void setID(String iD) {
        ID = iD;
    }

    public String getTenCV() {
        return tenCV;
    }

    public void setTenCV(String tenCV) {
        this.tenCV = tenCV;
    }

    public String getIDPhongBan() {
        return IDPhongBan;
    }

    public void setIDPhongBan(String iDPhongBan) {
        IDPhongBan = iDPhongBan;
    }
    
}