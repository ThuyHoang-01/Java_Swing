package MainRun; 

import GUI.GiaoDienChinh;
import GUI.GiaoDienChinh;

public class MainRun {
	
	public static void main(String[] args) {
		new GiaoDienChinh().setVisible(true);
	}

}
