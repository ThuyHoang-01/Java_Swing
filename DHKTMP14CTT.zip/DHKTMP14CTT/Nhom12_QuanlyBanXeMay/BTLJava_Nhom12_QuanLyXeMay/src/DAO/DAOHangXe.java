package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import connectDatabase.ConnectDB;

public class DAOHangXe {
	
	public ArrayList<String> getListMaHangXe(){
		Connection con = ConnectDB.getInstance().getConnection();
		ArrayList<String> a = new ArrayList<String>();
		String sql = "select MaHangXe, TenHangXe from [dbo].[HangXe]";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				a.add(rs.getString(1)+" ("+rs.getString(2)+" )");
			}
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
