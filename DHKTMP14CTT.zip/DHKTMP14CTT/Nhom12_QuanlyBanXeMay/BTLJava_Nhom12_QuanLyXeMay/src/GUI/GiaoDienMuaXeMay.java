package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import DAO.DAOKhachHang;
import DAO.DAOXeMay;
import entity.KhachHang;
import entity.XeMay;

public class GiaoDienMuaXeMay extends JFrame implements ActionListener, MouseListener {

	private static final long serialVersionUID = 1L;
	private JLabel lblTieude, lblMaKH, lblKH, lblMauXe, lblLoaiXe, lblSoPK, lblSoKhung, lblTenXe, lblTim;
	private JTextField txtKH, txtDiachi, txtSoDT, txtMauXe, txtLoaiXe, txtSoPK, txtTenXe, txtTim;
	private DAOKhachHang daoKhachHang = new DAOKhachHang();
	JButton btnThem, btnXoa, btnSua, btnTimkiem, btnLuu, btnExit;
	JComboBox cboMaKH, cboMaKhung, cbocTenXe;
	private DefaultComboBoxModel<String> cbcKH;
	private DAOXeMay daoXeMay = new DAOXeMay();
	private DefaultComboBoxModel<String> cbcSoKhung;

	/**
	* 
	*/

	public GiaoDienMuaXeMay() {
		setTitle("Quản lí bán xe 2 bánh");
		setSize(1000, 900);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		taoGiaoDien();

	}

	private void taoGiaoDien() {
		JPanel panel1 = new JPanel();

		// Container cp = getContentPane();

		Box b, b1, b2, b3, b4, b5, b6, b7, b8, b9;
		b = Box.createVerticalBox();
		panel1.add(b, BorderLayout.CENTER);
//	b.add(Box.createVerticalStrut(30));

		b.add(b1 = Box.createHorizontalBox());
		b1.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));

		b.add(b2 = Box.createHorizontalBox());
		b2.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b3 = Box.createHorizontalBox());
		b3.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b4 = Box.createHorizontalBox());
		b4.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b5 = Box.createHorizontalBox());
		b5.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b6 = Box.createHorizontalBox());
		b6.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b7 = Box.createHorizontalBox());
		b7.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b8 = Box.createHorizontalBox());
		b8.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));

		// cp.add(b);

		b1.add(lblTieude = new JLabel("Mua xe máy"));
		b1.setFont(new Font("Arial", Font.BOLD, 28));

		b2.add(lblKH = new JLabel("Khách hàng:"));
		b2.add(txtKH = new JTextField());
		txtKH.setEditable(false);

		Box b31, b32;
		b3.add(b31 = Box.createHorizontalBox());
		b3.add(b32 = Box.createHorizontalBox());
		b31.add(lblMaKH = new JLabel("Mã khách hàng:"));
		cbcKH = new DefaultComboBoxModel<String>();
		addtoListCombobox();
		cboMaKH = new JComboBox<String>(cbcKH);
		cboMaKH.setEditable(false);
		b31.add(cboMaKH);
		b31.add(Box.createHorizontalStrut(10));
		b31.add(lblSoKhung = new JLabel("Số khung:"));
		cbcSoKhung = new DefaultComboBoxModel<String>();
		addlistXeToCombobox();
		cboMaKhung = new JComboBox<String>(cbcSoKhung);
		cboMaKhung.setEditable(false);
		b32.add(cboMaKhung);

		b4.add(lblMauXe = new JLabel("Màu xe:"));
		b4.add(txtMauXe = new JTextField());
		txtMauXe.setEditable(false);

		b5.add(lblLoaiXe = new JLabel("Loại xe:"));
		b5.add(txtLoaiXe = new JTextField());
		txtLoaiXe.setEditable(false);

		b6.add(lblSoPK = new JLabel("Số PK:"));
		b6.add(txtSoPK = new JTextField());
		txtSoPK.setEditable(false);

		b7.add(lblTenXe = new JLabel("Tên Xe:"));
		b7.add(txtTenXe = new JTextField());
		txtTenXe.setEditable(false);
//		DefaultComboBoxModel<String> cbcTenXe = new DefaultComboBoxModel<String>();
//		cbcTenXe.addElement("Exciter");
//		cbcTenXe.addElement("Vison");
//		cbocTenXe = new JComboBox<String>(cbcTenXe);
//		cbocTenXe.setEditable(false);
//		b7.add(cbocTenXe);

		JTable table1 = new JTable();
		DefaultTableModel df = new DefaultTableModel();
		JScrollPane sr = new JScrollPane();
		String[] headers = "Khách hàng;Mã KH;Số khung;Màu xe;Loại xe;Số PK;Tên xe".split(";");
		df = new DefaultTableModel(headers, 0);
		b8.add(sr = new JScrollPane(table1 = new JTable(df), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		table1.setPreferredScrollableViewportSize(new Dimension(900, 400));

		JPanel pSouth1 = new JPanel();
		panel1.add(pSouth1, BorderLayout.SOUTH);
		pSouth1.setBorder(BorderFactory.createTitledBorder("Chọn tác vụ"));

		pSouth1.add(lblTim = new JLabel("Tìm mã khung xe:"));
		pSouth1.add(txtTim = new JTextField(15));
		pSouth1.add(btnThem = new JButton("THÊM"));
		pSouth1.add(btnXoa = new JButton("XÓA"));
		pSouth1.add(btnSua = new JButton("SỬA"));
		pSouth1.add(btnTimkiem = new JButton("TÌM KIẾM"));
		pSouth1.add(btnLuu = new JButton("LƯU"));
		pSouth1.add(btnExit = new JButton("EXIT"));
		txtTim.addActionListener(this);

		lblLoaiXe.setPreferredSize(lblKH.getPreferredSize());
		lblMauXe.setPreferredSize(lblKH.getPreferredSize());
		lblTenXe.setPreferredSize(lblKH.getPreferredSize());
		lblSoKhung.setPreferredSize(lblKH.getPreferredSize());
		lblMaKH.setPreferredSize(lblKH.getPreferredSize());
		lblSoPK.setPreferredSize(lblKH.getPreferredSize());
		
		cboMaKH.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				KhachHang a = daoKhachHang.getInfoKhachHang(cboMaKH.getSelectedItem().toString());
				txtKH.setText(a.getHoTenDep()+" "+a.getTen());
				txtDiachi.setText(a.getDiaChi());
				txtSoDT.setText(a.getSdt());
			}
		});
		
		cboMaKhung.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				XeMay a = daoXeMay.getInfoXeMay(cboMaKhung.getSelectedItem().toString());
				txtLoaiXe.setText(a.isLoaiXe() ? "xe ga" : "xe số");
				txtMauXe.setText(a.getMauXe());
				txtSoPK.setText(a.getSoPK());
				txtTenXe.setText(a.getTenXe());
			}
		});

		table1.addMouseListener(this);
		btnThem.addActionListener(this);
		btnXoa.addActionListener(this);
		btnSua.addActionListener(this);
		btnTimkiem.addActionListener(this);
		btnLuu.addActionListener(this);
		btnExit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
		add(panel1);

	}

	public void addtoListCombobox() {
		ArrayList<KhachHang> a = daoKhachHang.getListKhachHang();
		for (KhachHang khachHang : a) {
			cbcKH.addElement(khachHang.getMaKhachHang());
		}
	}
	
	public void addlistXeToCombobox() {
		ArrayList<XeMay> a = daoXeMay.getListXeMay();
		for (XeMay xeMay : a) {
			cbcSoKhung.addElement(xeMay.getSoKhung());
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}	
	public static void main(String[] args) {
		new GiaoDienMuaXeMay().setVisible(true);
	}
}
