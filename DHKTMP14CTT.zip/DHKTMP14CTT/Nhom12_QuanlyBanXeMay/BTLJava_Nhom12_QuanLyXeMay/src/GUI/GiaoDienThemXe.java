package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import DAO.DAOHangXe;
import DAO.DAOXeMay;
import entity.HangXe;
import entity.XeMay;

public class GiaoDienThemXe extends JFrame implements ActionListener, MouseListener {
	private JLabel lblTieude, lblNuocsx, lblLoaixe, lblMauxe, lblSokhung, lblSoPK, lblTim1, lbltenXe;
	private JTextField txtNuocsx, txtSokhung, txtTim1;
	private JButton btnThem, btnXoa, btnSua, btnTimkiem, btnLuu, btnExit;
	private JComboBox cbxMauXe, cbxLoaiXe, cbxSoPK, cbtenXe, cbxMaHangXe;
	private DAOXeMay daoXeMay = new DAOXeMay();
	private DAOHangXe daoHangXe = new DAOHangXe();
	private DefaultTableModel df;
	private DefaultComboBoxModel<String> cbcMode112;
	private static final long serialVersionUID = 1L;

	/**
	* 
	*/

	public GiaoDienThemXe() {
		setTitle("Quản lí bán xe 2 bánh");
		setSize(1000, 900);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		taoGiaoDien();

	}

	private void taoGiaoDien() {
		JPanel panel1 = new JPanel();

		// Container cp = getContentPane();

		Box b, b1, b9, b2, b3, b4, b5, b6, b7, b8;
		b = Box.createVerticalBox();
		panel1.add(b, BorderLayout.CENTER);
//	b.add(Box.createVerticalStrut(30));

		b.add(b1 = Box.createHorizontalBox());
		b1.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));

		b.add(b9 = Box.createHorizontalBox());
		b9.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));

		b.add(b2 = Box.createHorizontalBox());
		b2.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b3 = Box.createHorizontalBox());
		b3.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b4 = Box.createHorizontalBox());
		b4.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b5 = Box.createHorizontalBox());
		b5.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b6 = Box.createHorizontalBox());
		b6.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		b.add(b7 = Box.createHorizontalBox());
		b7.add(Box.createHorizontalStrut(20));
		b.add(Box.createVerticalStrut(10));
		// cp.add(b);

		b1.add(lblTieude = new JLabel("Thêm xe"), JLabel.CENTER);
		lblTieude.setFont(new Font("Arial", Font.BOLD, 28));

		b9.add(lbltenXe = new JLabel("Tên Xe:"));
		DefaultComboBoxModel<String> cbcMode = new DefaultComboBoxModel<String>();
		cbcMode.addElement("Exciter");
		cbcMode.addElement("Vison");
		cbcMode.addElement("ablack");
		cbcMode.addElement("Blade");
		cbtenXe = new JComboBox<String>(cbcMode);
		cbtenXe.setEditable(false);
		b9.add(cbtenXe);

		b2.add(lblNuocsx = new JLabel("Mã hãng xe:"));
		cbcMode112 = new DefaultComboBoxModel<String>();
		cbxMaHangXe = new JComboBox<String>(cbcMode112);
		
		getDataToCombobox();
		b2.add(cbxMaHangXe);

		b3.add(lblSokhung = new JLabel("Số khung xe:"));
		b3.add(txtSokhung = new JTextField());

		b4.add(lblMauxe = new JLabel("Màu xe:"));
		DefaultComboBoxModel<String> cbcModel1 = new DefaultComboBoxModel<String>();
		cbcModel1.addElement("Cam");
		cbcModel1.addElement("Trắng");
		cbcModel1.addElement("Đen nhám");
		cbxMauXe = new JComboBox<String>(cbcModel1);
		cbxMauXe.setEditable(false);
		b4.add(cbxMauXe);

		b5.add(lblLoaixe = new JLabel("Loại xe:"));
		DefaultComboBoxModel<String> cbcModel11 = new DefaultComboBoxModel<String>();
		cbcModel11.addElement("Xe số");
		cbcModel11.addElement("Xe tay côn");
		cbxLoaiXe = new JComboBox<String>(cbcModel11);
		cbxLoaiXe.setEditable(false);
		b5.add(cbxLoaiXe);

		b6.add(lblSoPK = new JLabel("Số PK:"));
		DefaultComboBoxModel<String> cbcModel12 = new DefaultComboBoxModel<String>();
		cbcModel12.addElement("90");
		cbcModel12.addElement("110");
		cbcModel12.addElement("150");
		cbxSoPK = new JComboBox<String>(cbcModel12);
		cbxSoPK.setEditable(false);
		b6.add(cbxSoPK);

		JTable table1 = new JTable();
		df = new DefaultTableModel();
		JScrollPane sr = new JScrollPane();
		String[] headers = "Khung xe;Tên xe;Màu xe;Hãng;Loại xe;Số PK".split(";");
		df = new DefaultTableModel(headers, 0);
		b7.add(sr = new JScrollPane(table1 = new JTable(df), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		getDataToTable();
		table1.setPreferredScrollableViewportSize(new Dimension(900, 400));

		JPanel pSouth1 = new JPanel();
		panel1.add(pSouth1, BorderLayout.SOUTH);
		pSouth1.setBorder(BorderFactory.createTitledBorder("Chọn tác vụ"));

		pSouth1.add(lblTim1 = new JLabel("Tìm mã khung xe:"));
		pSouth1.add(txtTim1 = new JTextField(15));
		pSouth1.add(btnThem = new JButton("THÊM"));
		pSouth1.add(btnXoa = new JButton("XÓA"));
		pSouth1.add(btnSua = new JButton("SỬA"));
		pSouth1.add(btnTimkiem = new JButton("TÌM KIẾM"));
		pSouth1.add(btnLuu = new JButton("LƯU"));
		pSouth1.add(btnExit = new JButton("EXIT"));
		txtTim1.addActionListener(this);

		lblLoaixe.setPreferredSize(lblNuocsx.getPreferredSize());
		lblMauxe.setPreferredSize(lblNuocsx.getPreferredSize());
		lblSokhung.setPreferredSize(lblNuocsx.getPreferredSize());
		lblSoPK.setPreferredSize(lblNuocsx.getPreferredSize());
		
		btnLuu.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				XeMay x = new XeMay();
				x.setSoKhung(txtSokhung.getText());
				
				x.setHangXe(new HangXe(cbxMaHangXe.getSelectedItem().toString().split(" ")[0]));
				x.setTenXe(cbtenXe.getSelectedItem().toString());
				x.setLoaiXe(cbxLoaiXe.getSelectedItem().toString() == "Xe số" ? false : true);
				x.setMauXe(cbxMauXe.getSelectedItem().toString());
				
				x.setSoPK(cbxSoPK.getSelectedItem().toString());
				if(!daoXeMay.themXe(x)) {
					JOptionPane.showMessageDialog(null, "Thêm không thành công!");
				}
				getDataToTable();
			}
		});

		table1.addMouseListener(this);
		btnThem.addActionListener(this);
		btnXoa.addActionListener(this);
		btnSua.addActionListener(this);
		btnTimkiem.addActionListener(this);
		btnLuu.addActionListener(this);

		btnExit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
		add(panel1);

	}
	
	public void getDataToCombobox() {
		ArrayList<String> a = daoHangXe.getListMaHangXe();
		for (String string : a) {
			cbcMode112.addElement(string);
		}
	}

	public void getDataToTable() {
		ArrayList<XeMay> a = daoXeMay.getListXeMay();
		df.setRowCount(0);
		for (XeMay i : a) {
			df.addRow(new Object[] { i.getSoKhung(), i.getTenXe(), i.getMauXe(), i.getHangXe().getTenHangXe(),
					i.isLoaiXe() ? "Xe ga" : "Xe Số", i.getSoPK() });
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}
