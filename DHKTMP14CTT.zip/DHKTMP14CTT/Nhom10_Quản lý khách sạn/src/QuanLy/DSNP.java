package QuanLy;

public class DSNP {

}
