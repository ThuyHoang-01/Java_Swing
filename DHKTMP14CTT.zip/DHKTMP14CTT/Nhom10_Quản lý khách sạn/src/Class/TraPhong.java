package Class;

public class TraPhong {
	private String hoTen;
	private String ma;
}
